# insp_window.py
import tkinter as tk
from tkinter import PhotoImage
from tkinter import ttk, messagebox
from database import Database

class InspWindow:
    def __init__(self, window):
        self.window = window
        self.window.title("Осмотры")
        self.window.geometry("900x600")
        self.db = Database()
        self.selected_user_id = None        # pdate, ptime, phive_id, presult, ptemp, pstatus
        self.setup_icons()
        self.setup_ui()
        self.load_data()

    def setup_icons(self):
        """Загрузка иконок для кнопок"""
        try:
            self.add_icon = PhotoImage(file="icons/add.png").subsample(1, 1)
            self.ref_icon = PhotoImage(file="icons/ref.png").subsample(1, 1)
            self.clr_icon = PhotoImage(file="icons/clr.png").subsample(1, 1)
        except:
            # Запасные иконки при отсутствии файлов
            self.add_icon = None
            self.ref_icon = None
            self.clr_icon = None

    def setup_ui(self):
        """Настройка интерфейса для осмотра"""
        # Фрейм для ввода данных
        input_frame = ttk.LabelFrame(self.window, text="Добавить/Редактировать осмотр")
        input_frame.pack(fill="x", padx=5, pady=3)

        # Поля ввода
        ttk.Label(input_frame, width=12, text="Дата:").grid(row=0, column=0, padx=5, pady=2, sticky="w")
        self.pdate_entry = ttk.Entry(input_frame, width=12)
        self.pdate_entry.grid(row=0, column=1, padx=5, pady=2, sticky="w")

        ttk.Label(input_frame, text="Время:").grid(row=1, column=0, padx=5, pady=2, sticky="w")
        self.ptime_entry = ttk.Entry(input_frame, width=12)
        self.ptime_entry.grid(row=1, column=1, padx=5, pady=2, sticky="w")

        ttk.Label(input_frame, text="ID улья:").grid(row=2, column=0, padx=5, pady=2, sticky="w")
        self.phive_id_entry = ttk.Entry(input_frame, width=10)
        self.phive_id_entry.grid(row=2, column=1, padx=5, pady=2, sticky="w")
        
        ttk.Label(input_frame, text="Результат:").grid(row=0, column=2, padx=5, pady=2, sticky="w")
        self.presult_entry = ttk.Entry(input_frame, width=80)
        self.presult_entry.grid(row=0, column=3, padx=5, pady=2, sticky="w")

        ttk.Label(input_frame, text="Температура:").grid(row=1, column=2, padx=5, pady=2, sticky="w")
        self.ptemp_entry = ttk.Entry(input_frame, width=12)
        self.ptemp_entry.grid(row=1, column=3, padx=5, pady=2, sticky="w")

        stat_opt = ["Новый", "Завершен"]
        ttk.Label(input_frame, text="Статус:").grid(row=2, column=2, padx=5, pady=2, sticky="w")
        self.pstatus_entry = ttk.Combobox(input_frame, values=stat_opt)
        self.pstatus_entry.grid(row=2, column=3, padx=5, pady=2, sticky="w")

        # Кнопки
        button_frame = ttk.Frame(input_frame)
        button_frame.grid(row=3, column=0, columnspan=4, pady=10, sticky="w")

        ttk.Button(button_frame, text="Добавить", command=self.add_insp, compound="left", image=self.add_icon).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Обновить", command=self.update_insp, compound="left", image=self.ref_icon).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Очистить", command=self.clear_fields, compound="left", image=self.clr_icon).pack(side="left", padx=5)

        # Таблица для отображения данных
        table_frame = ttk.LabelFrame(self.window, text="Список осмотров")
        table_frame.pack(fill="both", expand=True, padx=10, pady=5)
        

        columns = ("ID", "Дата", "Время","ID улья", "Результат", "Температура", "Статус")
        #columns = ("ID", "Дата", "Время","ID улья", "Результат", "Температура", "Статус")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=15)

        for col in columns:
            self.tree.heading(col, text=col)
#            self.tree.column(col, width=120)
            
        self.tree.column(0, width=10)
        self.tree.column(1, width=40)
        self.tree.column(2, width=20)
        self.tree.column(3, width=20)
        self.tree.column(4, width=250)
        self.tree.column(5, width=30)
        self.tree.column(6, width=60)


        self.tree.pack(fill="both", expand=True, padx=5, pady=5)
        self.tree.bind("<Double-1>", self.on_double_click)

    def load_data(self):
        """Загрузка данных пользователей в таблицу"""
        for item in self.tree.get_children():
            self.tree.delete(item)

        cursor = self.db.conn.cursor()
        cursor.execute("SELECT * FROM MY_INSPECT")
        inspects = cursor.fetchall()

        for inspect in inspects:
            self.tree.insert("", "end", values=inspect)

    def add_insp(self):
        """Добавление нового осмотра"""
        pdate = self.pdate_entry.get().strip()
        ptime = self.ptime_entry.get().strip()
        phive_id = self.phive_id_entry.get().strip()
        presult = self.presult_entry.get().strip()
        ptemp = self.ptemp_entry.get().strip()
        pstatus = self.pstatus_entry.get().strip()

        if not pdate or not ptime or not phive_id or not presult or not ptemp or not pstatus:
            messagebox.showerror("Ошибка", "Заполните все поля!")
            return

        try:
            temp = int(ptemp)
            if temp < -50 or temp > 50:
                raise ValueError
        except ValueError:
            messagebox.showerror("Ошибка", "Температура должна быть числом от -50 до 50 !")
            return

        try:
            cursor = self.db.conn.cursor()
            cursor.execute(
                "INSERT INTO MY_INSPECT(INS_DATE, INS_TIME, INS_HIVE_ID, INS_RESULT, INS_TEMP, INS_STATUS) VALUES (?, ?, ?, ?, ?, ?)",
                (pdate, ptime, phive_id, presult, ptemp, pstatus)
            )
            self.db.conn.commit()
            self.load_data()
            self.clear_fields()
            messagebox.showinfo("Успех", "Осмотр добавлен!")
        except sqlite3.IntegrityError:
            messagebox.showerror("Ошибка", "Ошибка добавления!")

    def update_insp(self):
        """Обновление выбранного пользователя"""
        if not self.selected_id:
            messagebox.showwarning("Предупреждение", "Выберите пользователя для обновления!")
            return
        pid=self.selected_id
        pdate = self.pdate_entry.get().strip()
        ptime = self.ptime_entry.get().strip()
        phive_id = self.phive_id_entry.get().strip()
        presult = self.presult_entry.get().strip()
        ptemp = self.ptemp_entry.get().strip()
        pstatus = self.pstatus_entry.get().strip()

        if not pdate or not ptime or not phive_id or not presult or not ptemp or not pstatus:
            messagebox.showerror("Ошибка", "Заполните все поля!")
            return

        try:
            temp = int(ptemp)
            if temp < -50 or temp > 50:
                raise ValueError
        except ValueError:
            messagebox.showerror("Ошибка", "Температура должна быть числом от -50 до 50 !")
            return

        try:
            cursor = self.db.conn.cursor()
            cursor.execute(
                "UPDATE MY_INSPECT SET INS_DATE = ?, INS_TIME = ?, INS_HIVE_ID = ?, INS_RESULT = ?, INS_TEMP = ?, INS_STATUS = ? WHERE INS_ID= ?",
                (pdate, ptime, phive_id, presult, ptemp, pstatus, pid)
            )
            self.db.conn.commit()
            self.load_data()
            self.clear_fields()
            messagebox.showinfo("Успех", "Данные обновлены!")
        except sqlite3.Error as e:
            messagebox.showerror("Ошибка", f"Не удалось обновить данные: {e}")


    def on_double_click(self, event):
        """Заполнение полей ввода при двойном клике на строку таблицы"""
        selected = self.tree.selection()
        if selected:
            values = self.tree.item(selected[0])['values']
            self.selected_id = values[0]
            self.pdate_entry.delete(0, tk.END)
            self.pdate_entry.insert(0, values[1])
            self.ptime_entry.delete(0, tk.END)
            self.ptime_entry.insert(0, str(values[2]))
            self.phive_id_entry.delete(0, tk.END)
            self.phive_id_entry.insert(0, values[3])
            self.presult_entry.delete(0, tk.END)
            self.presult_entry.insert(0, values[4])
            self.ptemp_entry.delete(0, tk.END)
            self.ptemp_entry.insert(0, str(values[5]))
            self.pstatus_entry.delete(0, tk.END)
            self.pstatus_entry.insert(0, values[6])

    def clear_fields(self):
        """Очистка полей ввода"""
        self.pdate_entry.delete(0, tk.END)
        self.ptime_entry.delete(0, tk.END)
        self.phive_id_entry.delete(0, tk.END)
        self.presult_entry.delete(0, tk.END)
        self.ptemp_entry.delete(0, tk.END)
        self.pstatus_entry.delete(0, tk.END)
        self.selected_id = None
