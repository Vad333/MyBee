# v.26.03.18 
# MYBEE
import os
import tkinter as tk
from menu import MainMenu

def main():
    root = tk.Tk()
    app = MainMenu(root)
    
    root.resizable(0, 0)
    print("START")
    root.mainloop()

if __name__ == "__main__":
    os.chdir('c:\\WORK\\PYTHON\\MYBEE\\') 
    main()
