# v.26.03.18 
# MYBEE
import os
import tkinter as tk
from tkinter import font
from menu import MainMenu

def main():
    root = tk.Tk()
    # Получаем стандартный шрифт
    default_font = font.nametofont("TkDefaultFont")
    text_font = font.nametofont("TkTextFont")
    # Меняем его параметры
    default_font.configure(family="Sans-Serif", size=11)
    text_font.configure(family="Sans-Serif", size=11)
    # Фрейм для ввода данных
    app = MainMenu(root)
    
    root.resizable(0, 0)
    print("START")
    root.mainloop()

if __name__ == "__main__":
    os.chdir('c:\\WORK\\PYTHON\\MYBEE\\') 
    main()
