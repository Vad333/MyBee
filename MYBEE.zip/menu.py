# menu.py
import tkinter as tk
from tkinter import PhotoImage
from hive_window import HiveWindow
from insp_window import InspWindow
from work_window import WorkWindow

class MainMenu:
    def __init__(self, root):
        self.root = root
        self.root.title("MYBEE")
        self.root.geometry("350x550")
        self.setup_icons()
        self.center_window()
        self.create_ui()

    def setup_icons(self):
        """Загрузка иконок для кнопок"""
        try:
            self.hive_icon = PhotoImage(file="icons/hive.png").subsample(1, 1)
            self.product_icon = PhotoImage(file="icons/box.png").subsample(1, 1)
            self.exit_icon = PhotoImage(file="icons/exit.png").subsample(1, 1)
            self.work_icon = PhotoImage(file="icons/work.png").subsample(1, 1)
            self.cfg_icon = PhotoImage(file="icons/cfg.png").subsample(1, 1)
        except:
            # Запасные иконки при отсутствии файлов
            self.hive_icon = None
            self.product_icon = None
            self.exit_icon = None
            self.work_icon = None
            self.cfg_icon = None

    def center_window(self):
        """Центрирование окна на экране"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')

    def create_ui(self):
        """Создание интерфейса главного меню"""
        main_frame = tk.Frame(self.root, padx=20, pady=20)
        main_frame.pack(expand=True)

        tk.Label(
            main_frame,
            text="Программа MYBEE",
            font=("Arial", 16, "bold")
        ).pack(pady=20)

        # Кнопка Объекты
        tk.Button(
            main_frame,
            text=" Объекты",
            font=("Arial", 11),
            command=self.open_hive_window,
            width=180,
            height=50,
            compound="left",
            image=self.hive_icon,
            anchor="w",
            padx=10
        ).pack(pady=10)

        # Кнопка осмотры
        tk.Button(
            main_frame,
            text=" Осмотры",
            font=("Arial", 11),
            command=self.open_insp_window,
            width=180,
            height=50,
            compound="left",
            image=self.product_icon,
            anchor="w",
            padx=10
        ).pack(pady=10)
        
        # Кнопка работы
        tk.Button(
            main_frame,
            text=" Работы",
            font=("Arial", 11),
            command=self.open_work_window,
            width=180,
            height=50,
            compound="left",
            image=self.work_icon,
            anchor="w",
            padx=10
        ).pack(pady=10)
        
        # Кнопка настройки
        tk.Button(
            main_frame,
            text=" Настройки",
            font=("Arial", 11),
            command=self.open_work_window,
            width=180,
            height=50,
            compound="left",
            image=self.cfg_icon,
            anchor="w",
            padx=10
        ).pack(pady=10)

        # Кнопка выхода
        tk.Button(
            main_frame,
            text=" Выход",
            font=("Arial", 11),
 #           command=self.root.quit(),
            command=self.exit_app,
            width=180,
            height=50,
            bg="red",
            fg="white",
            compound="left",
            image=self.exit_icon,
            anchor="w",
            padx=10
        ).pack(pady=10)

    def open_hive_window(self):
        """Открытие окна управления пользователями"""
        hive_window = tk.Toplevel(self.root)
        HiveWindow(hive_window)
        hive_window.grab_set()

    def open_insp_window(self):
        """Открытие окна управления пользователями"""
        insp_window = tk.Toplevel(self.root)
        InspWindow(insp_window)
        insp_window.grab_set()

    def open_work_window(self):
        """Открытие окна управления продуктами"""
        work_window = tk.Toplevel(self.root)
        WorkWindow(work_window)
        work_window.grab_set()

    def exit_app(self):
        self.root.destroy()