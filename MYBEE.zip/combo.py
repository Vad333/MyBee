import tkinter as tk
from tkinter import ttk
# Создаём окно
root = tk.Tk()
root.title("Выпадающий список")
root.geometry("300x200")

# Список значений для выпадающего списка
options = ["Python", "Java", "C++", "JavaScript"]

# Создаём Combobox
combo = ttk.Combobox(root, values=options, state="readonly")
combo.set("Выберите язык")
# Устанавливаем значение по умолчанию
combo.pack(pady=20)

# Функция для вывода выбранного значения
def get_selection():
    selected = combo.get()
    print(f"Вы выбрали: {selected}")

# Кнопка для вывода результата
button = tk.Button(root, text="Показать выбор", command=get_selection)
button.pack(pady=20)

# Запуск окна
root.mainloop()
