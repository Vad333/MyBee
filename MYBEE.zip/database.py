# database.py
import sqlite3

class Database:
    def __init__(self, db_name="mybee.db3"):
        self.conn = sqlite3.connect(db_name)


    def close(self):
        """Закрытие соединения с базой данных"""
        self.conn.close()
