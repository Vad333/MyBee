# products_window.py
import tkinter as tk
from tkinter import ttk, messagebox
from database import Database


class ProductsWindow:
    def __init__(self, window):
        self.window = window
        self.window.title("Управление продуктами")
        self.window.geometry("700x500")
        self.db = Database()
        self.selected_product_id = None

        self.setup_ui()
        self.load_data()

    def setup_ui(self):
        """Настройка интерфейса для продуктов"""
        # Фрейм для ввода данных
        input_frame = ttk.LabelFrame(self.window, text="Добавить/Редактировать продукт")
        input_frame.pack(fill="x", padx=10, pady=5)


        # Поля ввода
        ttk.Label(input_frame, text="Название:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.name_entry = ttk.Entry(input_frame, width=25)
        self.name_entry.grid(row=0, column=1, padx=5, pady=5)

        ttk.Label(input_frame, text="Цена:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.price_entry = ttk.Entry(input_frame, width=25)
        self.price_entry.grid(row=1, column=1, padx=5, pady=5)

        ttk.Label(input_frame, text="Количество:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.quantity_entry = ttk.Entry(input_frame, width=25)
        self.quantity_entry.grid(row=2, column=1, padx=5, pady=5)

        # Кнопки
        button_frame = ttk.Frame(input_frame)
        button_frame.grid(row=3, column=0, columnspan=2, pady=10)

        ttk.Button(button_frame, text="Добавить", command=self.add_product).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Обновить", command=self.update_product).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Очистить", command=self.clear_fields).pack(side="left", padx=5)

        # Таблица для отображения данных
        table_frame = ttk.LabelFrame(self.window, text="Список продуктов")
        table_frame.pack(fill="both", expand=True, padx=10, pady=5)

        columns = ("ID", "Название", "Цена", "Количество")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=15)

        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120)

        self.tree.pack(fill="both", expand=True, padx=5, pady=5)
        self.tree.bind("<Double-1>", self.on_double_click)

    def load_data(self):
        """Загрузка данных продуктов в таблицу"""
        for item in self.tree.get_children():
            self.tree.delete(item)

        cursor = self.db.conn.cursor()
        cursor.execute("SELECT * FROM products")
        products = cursor.fetchall()

        for product in products:
            self.tree.insert("", "end", values=product)

    def add_product(self):
        """Добавление нового продукта"""
        name = self.name_entry.get().strip()
        price = self.price_entry.get().strip()
        quantity = self.quantity_entry.get().strip()

        if not name or not price or not quantity:
            messagebox.showerror("Ошибка", "Заполните все поля!")
            return

        try:
            price = float(price)
            quantity = int(quantity)
            if price < 0 or quantity < 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Ошибка", "Цена и количество должны быть положительными числами!")
            return

        try:
            cursor = self.db.conn.cursor()
            cursor.execute(
                "INSERT INTO products (name, price, quantity) VALUES (?, ?, ?)",
                (name, price, quantity)
            )
            self.db.conn.commit()
            self.load_data()
            self.clear_fields()
            messagebox.showinfo("Успех", "Продукт добавлен!")
        except sqlite3.Error as e:
            messagebox.showerror("Ошибка", f"Не удалось добавить продукт: {e}")

    def update_product(self):
        """Обновление выбранного продукта"""
        if not self.selected_product_id:
            messagebox.showwarning("Предупреждение", "Выберите продукт для обновления!")
            return

        name = self.name_entry.get().strip()
        price = self.price_entry.get().strip()
        quantity = self.quantity_entry.get().strip()

        if not name or not price or not quantity:
            messagebox.showerror("Ошибка", "Заполните все поля!")
            return


        try:
            price = float(price)
            quantity = int(quantity)
            if price < 0 or quantity < 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Ошибка", "Цена и количество должны быть положительными числами!")
            return

        try:
            cursor = self.db.conn.cursor()
            cursor.execute(
                "UPDATE products SET name = ?, price = ?, quantity = ? WHERE id = ?",
                (name, price, quantity, self.selected_product_id)
            )
            self.db.conn.commit()
            self.load_data()
            self.clear_fields()
            messagebox.showinfo("Успех", "Данные обновлены!")
        except sqlite3.Error as e:
            messagebox.showerror("Ошибка", f"Не удалось обновить данные: {e}")


    def on_double_click(self, event):
        """Заполнение полей ввода при двойном клике на строку таблицы"""
        selected = self.tree.selection()
        if selected:
            values = self.tree.item(selected[0])['values']
            self.selected_product_id = values[0]
            self.name_entry.delete(0, tk.END)
            self.name_entry.insert(0, values[1])
            self.price_entry.delete(0, tk.END)
            self.price_entry.insert(0, str(values[2]))
            self.quantity_entry.delete(0, tk.END)
            self.quantity_entry.insert(0, str(values[3]))

    def clear_fields(self):
        """Очистка полей ввода"""
        self.name_entry.delete(0, tk.END)
        self.price_entry.delete(0, tk.END)
        self.quantity_entry.delete(0, tk.END)
        self.selected_product_id = None
