# hive_window.py
# MY_HIVE 
# HIV_ID, HIV_NUMB, HIV_TYPE, HIV_NAME, HIV_INFO, HIV_POS, HIV_COLOR, HIV_STATUS

import tkinter as tk
from tkinter import font
from tkinter import PhotoImage
from tkinter import ttk, messagebox
from database import Database

class HiveWindow:
    def __init__(self, window):
        self.window = window
        self.window.title("Управление объектами")
        self.window.geometry("980x600")
        self.db = Database()
        self.selected_id = None
        self.setup_icons()
        self.setup_ui()
        self.load_data()
        
        
    def setup_icons(self):
        """Загрузка иконок для кнопок"""
        try:
            self.add_icon = PhotoImage(file="icons/add.png").subsample(1, 1)
            self.ref_icon = PhotoImage(file="icons/ref.png").subsample(1, 1)
            self.clr_icon = PhotoImage(file="icons/clr.png").subsample(1, 1)
        except:
            # Запасные иконки при отсутствии файлов
            self.add_icon = None
            self.ref_icon = None
            self.clr_icon = None

    def setup_ui(self):
        """Настройка интерфейса для пользователей"""
        # Фрейм для ввода данных
        input_frame = ttk.LabelFrame(self.window, text="Добавить/Редактировать объект")
        input_frame.pack(fill="x", padx=10, pady=5)

        # Поля ввода
        ttk.Label(input_frame, text="Номер:").grid(row=0, column=0, padx=5, pady=2, sticky="w")
        self.numb_entry = ttk.Entry(input_frame, width=25)
        self.numb_entry.grid(row=0, column=1, padx=5, pady=2, sticky="w")

        cursor = self.db.conn.cursor()
        cursor.execute("SELECT TYP_NAME FROM MY_TYPE_HIVE")
        #spis=cursor.fetchall()
        spis=[row[0] for row in cursor.fetchall()]
        sel=tk.StringVar(input_frame)
        sel.set(spis)
        ttk.Label(input_frame, text="Тип:").grid(row=1, column=0, padx=5, pady=2, sticky="w")
        self.type_entry = ttk.Combobox(input_frame, textvariable=sel, values=spis, width=30)
        self.type_entry.grid(row=1, column=1, padx=5, pady=2, sticky="w")

        ttk.Label(input_frame, text="Название:").grid(row=2, column=0, padx=5, pady=2, sticky="w")
        self.name_entry = ttk.Entry(input_frame, width=25)
        self.name_entry.grid(row=2, column=1, padx=5, pady=2, sticky="w")

        ttk.Label(input_frame, text="Расположение:").grid(row=0, column=3, padx=5, pady=2, sticky="w")
        self.pos_entry = ttk.Entry(input_frame, width=25)
        self.pos_entry.grid(row=0, column=4, padx=5, pady=2, sticky="w")

        ttk.Label(input_frame, text="Цвет:").grid(row=1, column=3, padx=5, pady=2, sticky="w")
        self.color_entry = ttk.Entry(input_frame, width=25)
        self.color_entry.grid(row=1, column=4, padx=5, pady=2, sticky="w")
        
        stat_opt = ["Рабочий", "Пустой", "Запас", "Ремонт"]
        ttk.Label(input_frame, text="Статус:").grid(row=2, column=3, padx=5, pady=2, sticky="w")
        self.status_entry = ttk.Combobox(input_frame, values=stat_opt, width=25)
        self.status_entry.grid(row=2, column=4, padx=5, pady=2, sticky="w")

        ttk.Label(input_frame, text="Информация:").grid(row=3, column=0, padx=5, pady=2, sticky="w")
        self.info_entry = ttk.Entry(input_frame, width=80)
        self.info_entry.grid(row=3, column=1, columnspan=4, padx=5, pady=2, sticky="w")

        # Кнопки
        button_frame = ttk.Frame(input_frame)
        button_frame.grid(row=4, column=0, columnspan=4, pady=10, sticky="w")
        
        ttk.Button(button_frame, text="Добавить", command=self.add_hive, compound="left", image=self.add_icon).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Обновить", command=self.update_hive, compound="left", image=self.ref_icon).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Очистить", command=self.clear_fields, compound="left", image=self.clr_icon).pack(side="left", padx=5)

        # Таблица для отображения данных
        table_frame = ttk.LabelFrame(self.window, text="Список пользователей")
        table_frame.pack(fill="both", expand=True, padx=10, pady=5)


        columns = ("ID", "Номер", "Тип", "Название", "Информация", "Расположение", "Цвет", "Статус")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=15)

        for col in columns:
            self.tree.heading(col, text=col)
        self.tree.column(0, width=10)
        self.tree.column(1, width=30)
        self.tree.column(2, width=40)
        self.tree.column(3, width=40)
        self.tree.column(4, width=200)
        self.tree.column(5, width=30)
        self.tree.column(6, width=30)
        self.tree.column(7, width=30)
        
        self.tree.pack(fill="both", expand=True, padx=5, pady=5)
        self.tree.bind("<Double-1>", self.on_double_click)

    def load_data(self):
        """Загрузка данных пользователей в таблицу"""
        for item in self.tree.get_children():
            self.tree.delete(item)

        cursor = self.db.conn.cursor()
        cursor.execute("SELECT * FROM MY_HIVE")
        hives = cursor.fetchall()

        for hive in hives:
            self.tree.insert("", "end", values=hive)

    def add_hive(self):
        """Добавление нового объекта"""
        pnumb = self.numb_entry.get().strip()
        ptype = self.type_entry.get().strip()
        pname = self.name_entry.get().strip()
        pinfo = self.info_entry.get().strip()
        ppos = self.pos_entry.get().strip()
        pcolor = self.color_entry.get().strip()
        pstatus = self.status_entry.get().strip()
        
        if not pnumb or not ptype or not pname or not pinfo or not ppos or not pcolor or not pstatus:
            messagebox.showerror("Ошибка", "Заполните все поля!")
            return

        try:
            numb = int(pnumb)
            if numb < 0 or numb > 9999:
                raise ValueError
        except ValueError:
            messagebox.showerror("Ошибка", "Номер должен быть числом от 0 до 9999!")
            return

        try:
            cursor = self.db.conn.cursor()
            cursor.execute(
                "INSERT INTO MY_HIVE (HIV_NUMB, HIV_TYPE, HIV_NAME, HIV_INFO, HIV_POS, HIV_COLOR, HIV_STATUS) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (pnumb, ptype, pname, pinfo, ppos, pcolor, pstatus)
            )
            self.db.conn.commit()
            self.load_data()
            self.clear_fields()
            #messagebox.showinfo("Успех", "Объект добавлен!")
            print("Объект добавлен!")
        except sqlite3.Error as e:
            messagebox.showerror("Ошибка", f"Ошибка добавления:\n {e}")

    def update_hive(self):
        """Обновление выбранного пользователя"""
        if not self.selected_id:
            messagebox.showwarning("Предупреждение", "Выберите пользователя для обновления!")
            return

        pnumb = self.numb_entry.get().strip()
        ptype = self.type_entry.get().strip()
        pname = self.name_entry.get().strip()
        pinfo = self.info_entry.get().strip()
        ppos = self.pos_entry.get().strip()
        pcolor = self.color_entry.get().strip()
        pstatus = self.status_entry.get().strip()

        if not pnumb or not ptype or not pname or not pinfo or not ppos or not pcolor or not pstatus:
            messagebox.showerror("Ошибка", "Заполните все поля!")
            return

        try:
            numb = int(pnumb)
            if numb < 0 or numb > 9999:
                raise ValueError
        except ValueError:
            messagebox.showerror("Ошибка", "Номер должен быть числом от 0 до 9999!")
            return

        try:
            cursor = self.db.conn.cursor()
            cursor.execute(
                "UPDATE MY_HIVE SET HIV_NUMB = ?, HIV_TYPE = ?, HIV_NAME = ?, HIV_INFO = ?, HIV_POS = ?, HIV_COLOR = ?, HIV_STATUS = ? WHERE HIV_ID = ?",
                (pnumb, ptype, pname, pinfo, ppos, pcolor, pstatus, self.selected_id)
            )
            self.db.conn.commit()
            self.load_data()
            self.clear_fields()
            #messagebox.showinfo("Успех", "Данные обновлены!")
            print("Данные обновлены!")
        except sqlite3.Error as e:
            messagebox.showerror("Ошибка", f"Не удалось обновить данные:\n {e}")


    def on_double_click(self, event):
        """Заполнение полей ввода при двойном клике на строку таблицы"""
        selected = self.tree.selection()
        if selected:
            values = self.tree.item(selected[0])['values']
            self.selected_id = values[0]
            
            self.numb_entry.delete(0, tk.END)
            self.numb_entry.insert(0, values[1])
            
            self.type_entry.delete(0, tk.END)
            self.type_entry.insert(0, values[2])
            
            self.name_entry.delete(0, tk.END)
            self.name_entry.insert(0, values[3])
            
            self.info_entry.delete(0, tk.END)
            self.info_entry.insert(0, values[4])
            
            self.pos_entry.delete(0, tk.END)
            self.pos_entry.insert(0, values[5])
            
            self.color_entry.delete(0, tk.END)
            self.color_entry.insert(0, values[6])
            
            self.status_entry.delete(0, tk.END)
            self.status_entry.insert(0, values[7])

    def clear_fields(self):
        """Очистка полей ввода"""
        self.numb_entry.delete(0, tk.END)
        self.type_entry.delete(0, tk.END)
        self.name_entry.delete(0, tk.END)
        self.info_entry.delete(0, tk.END)
        self.pos_entry.delete(0, tk.END)
        self.color_entry.delete(0, tk.END)
        self.status_entry.delete(0, tk.END)
        self.selected_id = None
