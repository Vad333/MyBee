from tkinter import *
from tkinter import ttk

app = Tk()
app.resizable(False, False)

mainLayout = ttk.Frame(app, padding=10)
mainLayout.grid()

settings = ttk.Labelframe(mainLayout, text="Settings", padding=10, width=1000)
settings.grid()

settings.columnconfigure(0, weight=1)

my_label = ttk.Label(settings, text="Length limit (in seconds)")
my_label.grid()

my_spinbox = ttk.Spinbox(settings, from_=60, to=600, width=20)
my_spinbox.grid()

app.mainloop()
