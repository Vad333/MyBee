# insp_window.py
import tkinter as tk
from tkinter import font
from tkinter import PhotoImage
from tkinter import ttk, messagebox
from database import Database

class InspWindow:
    def __init__(self, window):
        self.window = window
        self.window.title("Осмотры")
        self.window.geometry("980x600")
        self.db = Database()
        self.selected_user_id = None        # pdate, ptime, phive_id, presult, ptemp, pstatus
        self.setup_icons()
        self.setup_ui()
        self.load_data()

    def setup_icons(self):
        """Загрузка иконок для кнопок"""
        try:
            self.add_icon = PhotoImage(file="icons/add.png").subsample(1, 1)
            self.ok_icon = PhotoImage(file="icons/ok.png").subsample(1, 1)
            self.clr_icon = PhotoImage(file="icons/clr.png").subsample(1, 1)
        except:
            # Запасные иконки при отсутствии файлов
            self.add_icon = None
            self.ok_icon = None
            self.clr_icon = None

    def setup_ui(self):
        """Настройка интерфейса для осмотра"""
        # Получаем стандартный шрифт
        default_font = font.nametofont("TkDefaultFont")
        print(default_font)
        # Меняем его параметры
        default_font.configure(family="Arial", size=11)
        
        
        style = ttk.Style()  
        style.configure("Treeview.Cell", borderwidth=1) 
        
        # Фрейм для ввода данных
        input_frame = ttk.LabelFrame(self.window, text="Добавить/Редактировать осмотр")
        input_frame.pack(fill="x", padx=5, pady=3)

        # Поля ввода
        ttk.Label(input_frame, width=12, text="Дата:").grid(row=0, column=0, padx=5, pady=2, sticky="w")
        self.pdate_entry = ttk.Entry(input_frame, width=12)
        self.pdate_entry.grid(row=0, column=1, padx=5, pady=2, sticky="w")

        cursor = self.db.conn.cursor()
        cursor.execute("SELECT HIV_NUMB FROM MY_HIVE ORDER BY HIV_NUMB")
        #spis=cursor.fetchall()
        spis=[row[0] for row in cursor.fetchall()]
        sel=tk.StringVar(input_frame)
        sel.set(spis)

        ttk.Label(input_frame, text="№ улья").grid(row=1, column=0, padx=5, pady=2, sticky="w")
        self.phive_id_entry = ttk.Combobox(input_frame, textvariable=sel, values=spis, width=10)
        self.phive_id_entry.grid(row=1, column=1, padx=5, pady=2, sticky="w")

        ttk.Label(input_frame, text="Улочек пчелы").grid(row=2, column=0, padx=5, pady=2, sticky="w")
        self.ppchul_entry = ttk.Entry(input_frame, width=12)
        self.ppchul_entry.grid(row=2, column=1, padx=5, pady=2, sticky="w")

        ttk.Label(input_frame, text="Всего рамок").grid(row=3, column=0, padx=5, pady=2, sticky="w")
        self.pramall_entry = ttk.Entry(input_frame, width=12)
        self.pramall_entry.grid(row=3, column=1, padx=5, pady=2, sticky="w")

        ttk.Label(input_frame, text="Рамок расплода").grid(row=0, column=2, padx=5, pady=2, sticky="w")
        self.pramras_entry = ttk.Entry(input_frame, width=12)
        self.pramras_entry.grid(row=0, column=3, padx=5, pady=2, sticky="w")

        ttk.Label(input_frame, text="Рамок вощины").grid(row=1, column=2, padx=5, pady=2, sticky="w")
        self.pramvos_entry = ttk.Entry(input_frame, width=12)
        self.pramvos_entry.grid(row=1, column=3, padx=5, pady=2, sticky="w")

        ttk.Label(input_frame, text="Вес мёда").grid(row=2, column=2, padx=5, pady=2, sticky="w")
        self.pvesmed_entry = ttk.Entry(input_frame, width=12)
        self.pvesmed_entry.grid(row=2, column=3, padx=5, pady=2, sticky="w")

        ttk.Label(input_frame, text="Температура:").grid(row=3, column=2, padx=5, pady=2, sticky="w")
        self.ptemp_entry = ttk.Entry(input_frame, width=12)
        self.ptemp_entry.grid(row=3, column=3, padx=5, pady=2, sticky="w")
        
        ttk.Label(input_frame, text="Результат:").grid(row=4, column=0, padx=5, pady=2, sticky="w")
        self.presult_entry = ttk.Entry(input_frame, width=75)
        self.presult_entry.grid(row=4, column=1, columnspan=3, padx=5, pady=2, sticky="w")

        # Кнопки
        button_frame = ttk.Frame(input_frame)
        button_frame.grid(row=5, column=0, columnspan=4, pady=10, sticky="w")

        ttk.Button(button_frame, text="Добавить", command=self.add_insp, compound="left", image=self.add_icon).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Записать", command=self.update_insp, compound="left", image=self.ok_icon).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Очистить", command=self.clear_fields, compound="left", image=self.clr_icon).pack(side="left", padx=5)

        # Таблица для отображения данных
        table_frame = ttk.LabelFrame(self.window, text="Список осмотров")
        table_frame.pack(fill="both", expand=True, padx=10, pady=5)
        

        columns = ("ID", "Дата", "№ улья", "Ул. пчелы", "Всего рам.", "Расплод", "Вощина", "Мёд кг.", "Темпер.", "Результат")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=15)
        
        for col in columns:
            self.tree.heading(col, text=col)
#            self.tree.column(col, width=120)
            
        self.tree.column(0, width=10)
        self.tree.column(1, width=50)
        self.tree.column(2, width=40)
        self.tree.column(3, width=40)
        self.tree.column(4, width=40)
        self.tree.column(5, width=40)
        self.tree.column(6, width=40)
        self.tree.column(7, width=40)
        self.tree.column(8, width=40)
        self.tree.column(9, width=120)        


        self.tree.pack(fill="both", expand=True, padx=5, pady=5)
        self.tree.bind("<Double-1>", self.on_double_click)

    def load_data(self):
        """Загрузка данных осмотра в таблицу"""
        for item in self.tree.get_children():
            self.tree.delete(item)

        cursor = self.db.conn.cursor()
        cursor.execute("SELECT * FROM MY_INSPECT")
        inspects = cursor.fetchall()

        for inspect in inspects:
            self.tree.insert("", "end", values=inspect)

    def add_insp(self):
        """Добавление нового осмотра"""
        pdate = self.pdate_entry.get().strip()
        phive_id = self.phive_id_entry.get().strip()
        ppchul = self.ppchul_entry.get().strip()
        pramall = self.pramall_entry.get().strip()
        pramras = self.pramras_entry.get().strip()
        pramvos = self.pramvos_entry.get().strip()
        pvesmed = self.pvesmed_entry.get().strip()
        ptemp = self.ptemp_entry.get().strip()        
        presult = self.presult_entry.get().strip()

        if not pdate or not phive_id or not presult:
            messagebox.showerror("Ошибка", "Заполните нужные поля!")
            return

        if ptemp != 'None':
            try:
                temp = int(ptemp)
                if (temp < -50 or temp > 50):
                    raise ValueError
            except ValueError:
                messagebox.showerror("Ошибка", "Температура должна быть числом от -50 до 50 !")
                return

        try:
            cursor = self.db.conn.cursor()
            cursor.execute(
                "INSERT INTO MY_INSPECT(INS_DATE, INS_HIVE_ID, INS_PCHUL, INS_RAMALL, INS_RAMRAS, INS_RAMVOS, INS_VESMED, INS_TEMP, INS_RESULT) VALUES (?, ?, ?, ?, ?, ?)",
                (pdate, phive_id, ppchul, pramall, pramras, pramvos, pvesmed, ptemp, presult)
            )
            self.db.conn.commit()
            self.load_data()
            self.clear_fields()
            #messagebox.showinfo("Успех", "Осмотр добавлен!")
            print("Осмотр добавлен!")
        except sqlite3.Error as e:
            messagebox.showerror("Ошибка", f"Ошибка добавления:\n {e}")

    def update_insp(self):
        """Обновление выбранного осмотра"""
        if not self.selected_id:
            messagebox.showwarning("Предупреждение", "Выберите осмотр для обновления!")
            return
        pid=self.selected_id
        pdate = self.pdate_entry.get().strip()
        phive_id = self.phive_id_entry.get().strip()
        ppchul = self.ppchul_entry.get().strip()
        pramall = self.pramall_entry.get().strip()
        pramras = self.pramras_entry.get().strip()
        pramvos = self.pramvos_entry.get().strip()
        pvesmed = self.pvesmed_entry.get().strip()
        ptemp = self.ptemp_entry.get().strip()        
        presult = self.presult_entry.get().strip()

        if not pdate or not phive_id or not presult:
            messagebox.showerror("Ошибка", "Заполните нужные поля!")
            return

        if ptemp != 'None':
            try:
                temp = int(ptemp)
                if (temp < -50 or temp > 50):
                    raise ValueError
            except ValueError:
                messagebox.showerror("Ошибка", "Температура должна быть числом от -50 до 50 !")
                return

        try:
            cursor = self.db.conn.cursor()
            cursor.execute(
                "UPDATE MY_INSPECT SET INS_DATE=?,INS_HIVE_ID=?,INS_PCHUL=?,INS_RAMALL=?,INS_RAMRAS=?,INS_RAMVOS=?,INS_VESMED=?,\
                  INS_TEMP = ?, INS_RESULT = ? WHERE INS_ID= ?",
                (pdate, phive_id, ppchul, pramall, pramras, pramvos, pvesmed, ptemp, presult, pid)
            )
            self.db.conn.commit()
            self.load_data()
            self.clear_fields()
            #messagebox.showinfo("Успех", "Данные обновлены!")
            print("Данные обновлены!")
        except sqlite3.Error as e:
            messagebox.showerror("Ошибка", f"Не удалось обновить данные:\n {e}")


    def on_double_click(self, event):
        """Заполнение полей ввода при двойном клике на строку таблицы"""
        selected = self.tree.selection()
        if selected:
            values = self.tree.item(selected[0])['values']
            self.selected_id = values[0]

            self.pdate_entry.delete(0, tk.END)
            self.pdate_entry.insert(0, values[1])

            self.phive_id_entry.delete(0, tk.END)
            self.phive_id_entry.insert(0, values[2])

            self.ppchul_entry.delete(0, tk.END)
            self.ppchul_entry.insert(0, str(values[3]))            

            self.pramall_entry.delete(0, tk.END)
            self.pramall_entry.insert(0, str(values[4]))

            self.pramras_entry.delete(0, tk.END)
            self.pramras_entry.insert(0, str(values[5]))

            self.pramvos_entry.delete(0, tk.END)
            self.pramvos_entry.insert(0, str(values[6])) 

            self.pvesmed_entry.delete(0, tk.END)
            self.pvesmed_entry.insert(0, str(values[7]))

            self.ptemp_entry.delete(0, tk.END)
            self.ptemp_entry.insert(0, str(values[8]))
            
            self.presult_entry.delete(0, tk.END)
            self.presult_entry.insert(0, str(values[9]))

    def clear_fields(self):
        """Очистка полей ввода"""
        self.pdate_entry.delete(0, tk.END)
        self.phive_id_entry.delete(0, tk.END)
        self.ppchul_entry.delete(0, tk.END)
        self.pramall_entry.delete(0, tk.END)
        self.pramras_entry.delete(0, tk.END)
        self.pramvos_entry.delete(0, tk.END)
        self.pvesmed_entry.delete(0, tk.END)        
        self.ptemp_entry.delete(0, tk.END)        
        self.presult_entry.delete(0, tk.END)
        self.selected_id = None
