# database.py
import sqlite3
import configparser
import os
from datetime import date

class Database:
    def __init__(self, db_name='mybee.db3'):
        config_file = 'mybee.ini'
        config = configparser.ConfigParser()
        if not os.path.exists(config_file):
            print('CREATE INI')
            config.add_section('BASE')
            config.set('BASE', 'FILE', 'mybee.db3')
            with open(config_file, "w", encoding="utf-8") as f:
                config.write(f)
        else:    
            config.read(config_file)
        db_name = config.get('BASE', 'FILE', fallback='mybee.db3')
        print('DB =',db_name)
        self.conn = sqlite3.connect(db_name)


    def close(self):
        """Закрытие соединения с базой данных"""
        today = date.today()
        fdate = today.isoformat()  # по умолчанию даёт формат YYYY-MM-DD
        print('Дата',fdate)
        cursor = self.conn.cursor()
        cursor.execute("UPDATE MY_CFG SET CFG_VALUE = ? WHERE CFG_NAME = ?",
                (fdate,'WORKDATE')
            )
        self.conn.commit()
        self.conn.close()
