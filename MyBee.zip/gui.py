# gui.py
import tkinter as tk
from tkinter import ttk, messagebox

class MainWindow:
    def __init__(self, root, db_manager):
        self.root = root
        self.db_manager = db_manager
        self.selected_user_id = None

        self.setup_ui()
        self.load_data()

    def setup_ui(self):
        """Настройка интерфейса"""
        self.root.title("Управление базой данных пользователей")
        self.root.geometry("700x500")

        # Создание меню
        self.create_menu()

        # Фрейм для ввода данных
        input_frame = ttk.LabelFrame(self.root, text="Добавить/Редактировать пользователя")
        input_frame.pack(fill="x", padx=10, pady=5)

        # Поля ввода
        ttk.Label(input_frame, text="Имя:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.name_entry = ttk.Entry(input_frame, width=25)
        self.name_entry.grid(row=0, column=1, padx=5, pady=5)

        ttk.Label(input_frame, text="Возраст:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.age_entry = ttk.Entry(input_frame, width=25)
        self.age_entry.grid(row=1, column=1, padx=5, pady=5)

        ttk.Label(input_frame, text="Email:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.email_entry = ttk.Entry(input_frame, width=25)
        self.email_entry.grid(row=2, column=1, padx=5, pady=5)

        # Кнопки
        button_frame = ttk.Frame(input_frame)
        button_frame.grid(row=3, column=0, columnspan=2, pady=10)

        ttk.Button(button_frame, text="Добавить", command=self.add_user).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Обновить", command=self.update_user).pack(side="left", padx=5)
        ttk.Button(button_frame, text="Очистить", command=self.clear_fields).pack(side="left", padx=5)

        # Таблица для отображения данных
        table_frame = ttk.LabelFrame(self.root, text="Список пользователей")
        table_frame.pack(fill="both", expand=True, padx=10, pady=5)

        columns = ("ID", "Имя", "Возраст", "Email")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=15)

        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=120)

        self.tree.pack(fill="both", expand=True, padx=5, pady=5)

        # Привязка события двойного клика
        self.tree.bind("<Double-1>", self.on_double_click)

    def create_menu(self):
        """Создание основного меню"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)

        # Меню «Файл»
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Файл", menu=file_menu)
        file_menu.add_command(label="Обновить данные", command=self.load_data)
        file_menu.add_separator()
        file_menu.add_command(label="Выход", command=self.root.quit)

        # Меню «Помощь»
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Помощь", menu=help_menu)
        help_menu.add_command(label="О программе", command=self.show_about)

    def load_data(self):
        """Загрузка данных в таблицу"""
        for item in self.tree.get_children():
            self.tree.delete(item)

        users = self.db_manager.get_all_users()
        for user in users:
            self.tree.insert("", "end", values=user)

    def add_user(self):
        """Добавление нового пользователя"""
        name = self.name_entry.get().strip()
        age = self.age_entry.get().strip()
        email = self.email_entry.get().strip()

        if not name or not age or not email:
            messagebox.showerror("Ошибка", "Заполните все поля!")
            return

        try:
            age = int(age)
            if age < 0 or age > 150:
                raise ValueError
        except ValueError:
            messagebox.showerror("Ошибка", "Возраст должен быть числом от 0 до 150!")
            return

        if self.db_manager.add_user(name, age, email):
            self.load_data()
            self.clear_fields()
            messagebox.showinfo("Успех", "Пользователь добавлен!")
        else:
            messagebox.showerror("Ошибка", "Email уже существует!")

    def update_user(self):
        """Обновление выбранного пользователя"""
        if not self.selected_user_id:
            messagebox.showwarning("Предупреждение", "Выберите пользователя для обновления!")
            return

        name = self.name_entry.get().strip()
        age = self.age_entry.get().strip()
        email = self.email_entry.get().strip()

        if not name or not age or not email:
            messagebox.showerror("Ошибка", "Заполните все поля!")
            return

        try:
            age = int(age)
            if age < 0 or age > 150:
                raise ValueError
        except ValueError:
            messagebox.showerror("Ошибка", "Возраст должен быть числом от 0 до 150!")
            return

        if self.db_manager.update_user(self.selected_user_id, name, age, email):
            self.load_data()
            self.clear_fields()
            messagebox.showinfo("Успех", "Данные обновлены!")
        else:
            messagebox.showerror("Ошибка", "Не удалось обновить данные!")

    def on_double_click(self, event):
        """Заполнение полей ввода при двойном клике на строку таблицы"""
        selected = self.tree.selection()
        if selected:
            values = self.tree.item(selected[0])['values']
            self.selected_user_id = values[0]
            self.name_entry.delete(0, tk.END)
            self.name_entry.insert(0, values[1])
            self.age_entry.delete(0, tk.END)
            self.age_entry.insert(0, str(values[2]))
            self.email_entry.delete(0, tk.END)
            self.email_entry.insert(0, values[3])

    def clear_fields(self):
        """Очистка полей ввода"""
        self.name_entry.delete(0, tk.END)
        self.age_entry.delete(0, tk.END)
        self.email_entry.delete(0, tk.END)
        self.selected_user_id = None

    def show_about(self):
        """Показать информацию о программе"""
        messagebox.showinfo(
            "О программе",
            "Система управления пользователями\n"
            "Версия 1.0\n"
            "Использование Tkinter и SQLite"
        )
