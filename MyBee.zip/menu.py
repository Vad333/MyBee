# menu.py
import tkinter as tk
from tkinter import PhotoImage
from users_window import UsersWindow
from products_window import ProductsWindow

class MainMenu:
    def __init__(self, root):
        self.root = root
        self.root.title("MYBEE")
        self.root.geometry("450x350")
        self.setup_icons()
        self.center_window()
        self.create_ui()

    def setup_icons(self):
        """Загрузка иконок для кнопок"""
        try:
            self.user_icon = PhotoImage(file="icons/user.png").subsample(2, 2)
            self.product_icon = PhotoImage(file="icons/box.png").subsample(2, 2)
            self.exit_icon = PhotoImage(file="icons/exit.png").subsample(2, 2)
        except:
            # Запасные иконки при отсутствии файлов
            self.user_icon = None
            self.product_icon = None
            self.exit_icon = None

    def center_window(self):
        """Центрирование окна на экране"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f'{width}x{height}+{x}+{y}')

    def create_ui(self):
        """Создание интерфейса главного меню"""
        main_frame = tk.Frame(self.root, padx=20, pady=20)
        main_frame.pack(expand=True)

        tk.Label(
            main_frame,
            text="Программа MYBEE",
            font=("Arial", 16, "bold")
        ).pack(pady=20)

        # Кнопка управления пользователями
        tk.Button(
            main_frame,
            text=" Управление пользователями",
            command=self.open_users_window,
            width=200,
            height=50,
            compound="left",
            image=self.user_icon,
            anchor="w",
            padx=10
        ).pack(pady=10)

        # Кнопка управления продуктами
        tk.Button(
            main_frame,
            text=" Управление продуктами",
            command=self.open_products_window,
            width=200,
            height=50,
            compound="left",
            image=self.product_icon,
            anchor="w",
            padx=10
        ).pack(pady=10)

        # Кнопка выхода
        tk.Button(
            main_frame,
            text=" Выход",
            command=self.root.quit,
            width=200,
            height=50,
            bg="red",
            fg="white",
            compound="left",
            image=self.exit_icon,
            anchor="w",
            padx=10
        ).pack(pady=10)

    def open_users_window(self):
        """Открытие окна управления пользователями"""
        users_window = tk.Toplevel(self.root)
        UsersWindow(users_window)

    def open_products_window(self):
        """Открытие окна управления продуктами"""
        products_window = tk.Toplevel(self.root)
        ProductsWindow(products_window)
